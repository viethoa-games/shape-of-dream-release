# HƯỚNG DẪN CÀI ĐẶT — Vietnamese Localization (Shape of Dreams)

> Bản Việt hóa KHÔNG CHÍNH THỨC, do cộng đồng thực hiện. Không liên kết với Lizard Smoothie.
> **Việt hóa bởi Tấn Nguyễn — tannguyenvnkg@gmail.com** (contact for work)
> Phiên bản ngôn ngữ hiển thị trong **mô tả mod** (Mod Manager):
> dòng **"Phiên bản: vX.Y.Z"**.

## Yêu cầu

- Shape of Dreams bản PC (Steam), build **r.1.4.0.13_s** hoặc mới hơn.
- Không cần cài thêm BepInEx/MelonLoader — game có mod loader sẵn.

## Cài đặt

1. Mở thư mục cài game, ví dụ:
   `D:\SteamLibrary\steamapps\common\Shape of Dreams\`
2. Chép thư mục `Mods\ShapeOfDreams_VI` (trong gói zip này) vào thư mục `Mods\`
   của game. Kết quả:

   ```text
   Shape of Dreams\
   └── Mods\
       └── ShapeOfDreams_VI\
           ├── about\
           ├── bin\ShapeOfDreams_VI.dll
           └── locales\vi-VN.json
   ```

3. Mở game → màn hình chính → **Mods** → bật **Vietnamese Localization (Tiếng Việt)**.
   (Nếu game đang chạy, tải lại mod theo hướng dẫn của Mod Manager.)
4. Vào **Language / Ngôn ngữ** ở màn hình chính → chọn **Tiếng Việt**.

## Gỡ cài đặt

- Tắt mod trong Mod Manager, hoặc xóa thư mục `Mods\ShapeOfDreams_VI`.

## Kiểm tra lỗi

- Mở log: `%USERPROFILE%\AppData\LocalLow\Lizard Smoothie\Shape of Dreams\Player.log`
- Tìm dòng `[ShapeOfDreams_VI]`. Ví dụ log thành công:
  `[ShapeOfDreams_VI] Injected vi-VN localization (N fields applied).`
- Nếu thấy `Locale file not found` → kiểm tra lại đường dẫn `locales\vi-VN.json`.
- Nếu game hiển thị tiếng Anh ở hầu hết chỗ: đúng với bản pilot
  (chuỗi chưa dịch fallback về tiếng Anh).

## Cập nhật bản dịch không cần tải lại mod

- Có thể chỉ cần thay file `locales\vi-VN.json` bằng bản mới nhất.

## Lưu ý khi chơi multiplayer (co-op)

- Mod này chỉ thay đổi ngôn ngữ phía client (bạn), không đổi gameplay.
- Người chơi khác không cần cài mod để chơi cùng.

---

## English quick install

1. Copy `Mods\ShapeOfDreams_VI` into `<game>\Mods\`.
2. Launch the game → **Mods** → enable **Vietnamese Localization (Tiếng Việt)**.
3. Open **Language** on the title screen → select **Tiếng Việt**.
4. Logs: `Player.log` in `%USERPROFILE%\AppData\LocalLow\Lizard Smoothie\Shape of Dreams\`.
